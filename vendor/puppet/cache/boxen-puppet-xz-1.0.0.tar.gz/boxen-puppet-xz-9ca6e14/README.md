# XZ Puppet Module for Boxen

Installs xz.

[![Build Status](https://travis-ci.org/tommetge/puppet-xz.png?branch=master)](https://travis-ci.org/tommetge/puppet-xz)

## Usage

```puppet
include xz
```

## Required Puppet Modules

* `boxen`
